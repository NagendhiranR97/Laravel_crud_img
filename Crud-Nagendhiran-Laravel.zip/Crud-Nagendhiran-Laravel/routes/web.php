<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\StudInsertController;
use App\Http\Controllers\LoginController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/successlogin', [StudInsertController::class, 'index']);
Route::post('add-update-student', [StudInsertController::class, 'store']);
Route::post('edit-student', [StudInsertController::class, 'edit']);
Route::post('delete-student', [StudInsertController::class, 'destroy']);

Route::get('/', [LoginController::class, 'index']);
Route::post('/main/checklogin', [LoginController::class, 'checklogin']);
Route::get('main/successlogin', [LoginController::class, 'successlogin']);
Route::get('main/logout', [LoginController::class, 'logout']);

Route::get('main/imageupload', [StudInsertController::class, 'img_index']);
Route::post('multi_images', [StudInsertController::class, 'multi_images']);

Route::prefix('image')->group(function () {
   Route::get('uploads/{filename}',[StudInsertController::class, 'showJobImage'])
   ->name('jobImage');
});