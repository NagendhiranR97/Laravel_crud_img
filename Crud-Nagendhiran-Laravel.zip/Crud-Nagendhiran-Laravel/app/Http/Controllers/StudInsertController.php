<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Models\StudInsert;
use App\Models\Image;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Response;
use Illuminate\Support\Facades\Storage;

class StudInsertController extends Controller
{

    public function index()
    {
        $data['students'] = StudInsert::orderBy('id','desc')->paginate(5);
        //$data['images'] = Image::orderBy('id','desc')->paginate(5);
   
        return view('student.main',$data);
    }

    public function img_index(){
        $data['images'] = Image::orderBy('id','desc')->paginate(5);
   
        return view('images.main',$data);
    }

    public function multi_images(Request $request){
        if ($request->hasfile('files')) {
            $images = $request->file('files');

            foreach($images as $image) {
                $name = $image->getClientOriginalName();
                $path = $image->storeAs('multiple', $name, 'public');

                Image::create([
                    'userid' => '1',
                    'name' => $name,
                    'path' => '/storage/'.$path
                  ]);
            }
         }
         return response()->json(['success' => true]);
    }

    public function store(Request $request)
    {
       
       //print_r($request->file('image'));die;
        // $userid = $request->id;
        // echo $request->id;

        // if ($request->hasfile('files')) {
        //     $images = $request->file('files');

        //     foreach($images as $image) {
        //         $name = $image->getClientOriginalName();
        //         $path = $image->storeAs('uploads', $name, 'public');

        //         Image::create([
        //             'userid' => $userid,
        //             'name' => $name,
        //             'path' => '/storage/'.$path
        //           ]);
        //     }
        //  }
                $images = $request->file('files');
                foreach($images as $image) {
                $name = $image->getClientOriginalName();
                $path = $image->storeAs('uploads', $name, 'public');
            }

        $studentdetails   =   StudInsert::updateOrCreate(
                    [
                        'id' => $request->id
                    ],
                    [
                        'first_name' => $request->first_name, 
                        'last_name' => $request->last_name,
                        'city_name' => $request->city_name,
                        'email' => $request->email,
                        'img_name' => $name,
                        'img_path' => '/storage/'.$path
                    ]);
    
        return response()->json(['success' => true]);
    }
    
    public function edit(Request $request)
    {   
        $where = array('id' => $request->id);
        $studentdetails  = StudInsert::where($where)->first();
 
        return response()->json($studentdetails);
    }
 
   
    
    public function destroy(Request $request)
    {
        $studentdetails = StudInsert::where('id',$request->id)->delete();
   
        return response()->json(['success' => true]);
    }

    protected function showJobImage($filename)
{
   //check image exist or not
   $exists = Storage::disk('public')->exists('uploads/'.$filename);
   
   if($exists) {
      
      //get content of image
      $content = Storage::get('public/uploads/'.$filename);
      
      //get mime type of image
      $mime = Storage::mimeType('public/uploads/'.$filename);
      //prepare response with image content and response code
      $response = Response::make($content, 200);
      //set header 
      $response->header("Content-Type", $mime);
      // return response
      return $response;
   } else {
      abort(404);
   }
}
}