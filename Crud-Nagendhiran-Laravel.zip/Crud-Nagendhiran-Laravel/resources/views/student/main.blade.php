<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student details</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" >
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container mt-2">
    <div class="row">
        <div class="col-md-12 card-header text-center font-weight-bold">
          <h2>Student details</h2>
        </div>
        <div class="col-md-6 mt-1 mb-2"><button type="button" id="addNewstudent" class="btn btn-success">Add</button></div>
        <div class="col-md-3 mt-1 mb-2"><a href="{{ url('/main/logout') }}"><b>Logout</b></a></div>
        <div class="col-md-3 mt-1 mb-2"><a href="{{ url('/main/imageupload') }}"><b>multiple image upload</b></a></div>
      </br>
      </br>
        <div class="col-md-12">
            <table class="table">
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">first_name</th>
                  <th scope="col">last_name</th>
                  <th scope="col">email</th>
                  <th scope="col">city</th>
                  <th scope="col">Images</th>
                  <th scope="col">Actions</th>
                </tr>
              </thead>
              <tbody> 
                @foreach ($students as $student)
                <tr>
                    <td>{{ $student->id }}</td>
                    <td>{{ $student->first_name }}</td>
                    <td>{{ $student->last_name }}</td>
                    <td>{{ $student->email }}</td>
                    <td>{{ $student->city_name }}</td>
                    <td>
                      <img width="30%" class="img-circle" src="{{ route('jobImage', $student->img_name) }}">
                  </td>
                    <td>
                       <a href="javascript:void(0)" class="btn btn-primary edit" data-id="{{ $student->id }}">Edit</a>
                      <a href="javascript:void(0)" class="btn btn-primary delete" data-id="{{ $student->id }}">Delete</a>
                    </td>
                </tr>
                @endforeach
              </tbody>
            </table>
            
        </div>
    </div>        
</div>
<!-- boostrap model -->
    <div class="modal fade" id="ajax-student-model" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title" id="ajaxstudentModel"></h4>
          </div>
          <div class="modal-body">
            <form action="javascript:void(0)" id="addEditstudentForm" name="addEditstudentForm" class="form-horizontal" method="POST" enctype="multipart/form-data">
              <input type="hidden" name="id" id="id">
              <div class="form-group">
                <label for="name" class="col-sm-2 control-label">First Name</label>
                <div class="col-sm-12">
                  <input type="text" class="form-control" id="first_name" name="first_name" placeholder="Enter student Name" value="" maxlength="50" required="">
                </div>
              </div>
              <div class="form-group">
                <label for="name" class="col-sm-2 control-label">Last Name</label>
                <div class="col-sm-12">
                  <input type="text" class="form-control" id="last_name" name="last_name" placeholder="Enter student Name" value="" maxlength="50" required="">
                </div>
              </div> 
              <div class="form-group">
              <label class="col-sm-2 control-label">Email</label>
              <input type="email" name="email" id="email" class="form-control" placeholder="Email Id" value="" required="">
            </div>
            <div class="form-group">
              <label class="col-sm-2 control-label">Image</label>
            <input type="file" name="files[]" id="files" placeholder="Choose files" value=''multiple >
            <div><img id='edit-img' name='edit-img' src=""></div>
          </div>
              <div class="form-group">
              <label class="col-sm-2 control-label">City</label>
              <select name="city_name" id="city_name" class=" form-control" required>
                <option value="delhi">Delhi</option>
                <option value="mumbai">Mumbai</option>
                <option value="kolkata">Kolkata</option>
                <option value="chennai">Chennai</option>
              </select>
            </div>
              <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-primary" id="btn-save" value="addNewstudent">Save changes
                </button>
              </div>
            </form>
          </div>
          <div class="modal-footer">
            
          </div>
        </div>
      </div>
    </div>
<!-- end bootstrap model -->
<script type="text/javascript">
 $(document).ready(function($){
    $.ajaxSetup({
        headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $('#addNewstudent').click(function () {
       $('#addEditstudentForm').trigger("reset");
       $('#ajaxstudentModel').html("Add student");
       $('#ajax-student-model').modal('show');
    });
 
    $('body').on('click', '.edit', function () {
        var id = $(this).data('id');
         var img_url = 'http://127.0.0.1:8000/image/uploads/';
        // ajax
        $.ajax({
            type:"POST",
            url: "{{ url('edit-student') }}",
            data: { id: id },
            dataType: 'json',
            success: function(res){
              $('#ajaxstudentModel').html("Edit student");
              $('#ajax-student-model').modal('show');
              $('#id').val(res.id);
              $('#first_name').val(res.first_name);
              $('#last_name').val(res.last_name);
              $('#email').val(res.email);
              $('#city_name').val(res.city_name);
              $('#files').val(res.img_name);
              $('#edit-img').attr("src",img_url+res.img_name);
           }
        });
    });
    $('body').on('click', '.delete', function () {
       if (confirm("Delete Record?") == true) {
        var id = $(this).data('id');
         
        // ajax
        $.ajax({
            type:"POST",
            url: "{{ url('delete-student') }}",
            data: { id: id },
            dataType: 'json',
            success: function(res){
              window.location.reload();
           }
        });
       }
    });
    $('#addEditstudentForm').on('submit', function (event) {
          // var id = $("#id").val();
          // var first_name = $("#first_name").val();
          // var last_name = $("#last_name").val();
          // var email = $("#email").val();
          // var city_name = $("#city_name").val();
          //var fileInput = document.getElementById('images');
var formData = new FormData(this);
let TotalFiles = $('#files')[0].files.length; //Total files
let files = $('#files')[0];
for (let i = 0; i < TotalFiles; i++) {
formData.append('files' + i, files.files[i]);
}
      //alert(formData);
          $("#btn-save").html('Please Wait...');
          $("#btn-save"). attr("disabled", true);
         
        // ajax
        $.ajax({
            type:"POST",
            url: "{{ url('add-update-student') }}",
            cache:false,
            contentType: false,
            processData: false,
            dataType: 'json',
            data: new FormData(this),
            success: function(res){
             window.location.reload();
            $("#btn-save").html('Submit');
            $("#btn-save"). attr("disabled", false);
           }
        });
    });
});
</script>
</body>
</html>