<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Image uploads</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" >
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
  <form action="javascript:void(0)" id="addEditstudentForm" name="addEditstudentForm" class="form-horizontal" method="POST" enctype="multipart/form-data">
 <input type="file" name="files[]" id="files" placeholder="Choose files" value=''multiple >

 <button type="submit" class="btn btn-primary" id="btn-save" value="addNewstudent">Save changes
                </button>
  </form>
<script type="text/javascript">
   $(document).ready(function($){
    $.ajaxSetup({
        headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

$('#addEditstudentForm').on('submit', function (event) {
          // var id = $("#id").val();
          // var first_name = $("#first_name").val();
          // var last_name = $("#last_name").val();
          // var email = $("#email").val();
          // var city_name = $("#city_name").val();
          //var fileInput = document.getElementById('images');
var formData = new FormData(this);
let TotalFiles = $('#files')[0].files.length; //Total files
let files = $('#files')[0];
for (let i = 0; i < TotalFiles; i++) {
formData.append('files' + i, files.files[i]);
}
      //alert(formData);
          $("#btn-save").html('Please Wait...');
          $("#btn-save"). attr("disabled", true);
         
        // ajax
        $.ajax({
            type:"POST",
            url: "{{ url('multi_images') }}",
            cache:false,
            contentType: false,
            processData: false,
            dataType: 'json',
            data: new FormData(this),
            success: function(res){
             window.location.reload();
            $("#btn-save").html('Submit');
            $("#btn-save"). attr("disabled", false);
           }
        });
    });

  });
</script>
</body>
</html>